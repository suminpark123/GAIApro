import React from "react";
import { useState } from "react";
import ReactApexChart from "react-apexcharts";
// reactstrap components
import { Button, FormGroup, Input, Modal, Row, Col } from "reactstrap";

function Examplesu0() {
  const [liveDemo, setLiveDemo] = React.useState(false);
  const [state3, setState3] = useState({
    series: [
      {
        name: "Desktops",
        data: [10, 41, 35, 51, 140, 90, 80, 70, 88],
      },
    ],
    options: {
      colors: ["#009000"],
      chart: {
        height: 350,
        type: "line",

        zoom: {
          enabled: false,
        },
      },
      dataLabels: {
        enabled: false,
      },
      stroke: {
        curve: "straight",
      },
      title: {
        text: "처리과정",
        align: "left",
      },
      grid: {
        row: {
          colors: ["#f3f3f3", "transparent"], // takes an array which will be repeated on columns
          opacity: 0.5,
        },
      },
      xaxis: {
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
        ],
      },
    },
  });

  return (
    <>
      <Button
        color="primary"
        type="button"
        onClick={() => setLiveDemo(true)}
        style={{ borderRadius: "20px" }}
      >
        자세히 알아보기
      </Button>
      <Modal isOpen={liveDemo} toggle={() => setLiveDemo(false)} size="lg">
        <div className="modal-header">
          <h5 className="modal-title" id="exampleModalLiveLabel">
            Modal title
          </h5>
          <button
            aria-label="Close"
            className="close"
            data-dismiss="modal"
            type="button"
            onClick={() => setLiveDemo(false)}
          >
            <span aria-hidden={true}>×</span>
          </button>
        </div>
        <div className="modal-body">
          <p>
            {/* 추가 */}
            <Row>
              <Col>
                <ReactApexChart
                  options={state3.options}
                  series={state3.series}
                  type="line"
                  height={350}
                />
              </Col>
            </Row>
            {/* 추가완료 */}
          </p>
        </div>
        <div className="modal-footer">
          <div className="left-side">
            <Button
              className="btn-link"
              color="default"
              data-dismiss="modal"
              type="button"
              onClick={() => setLiveDemo(false)}
            >
              Never mind
            </Button>
          </div>
          <div className="divider" />
          <div className="right-side">
            <Button
              className="btn-link"
              color="danger"
              type="button"
              onClick={() => setLiveDemo(false)}
            >
              Delete
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
}

export default Examplesu0;
